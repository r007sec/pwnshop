/* PwnShop — Mobile Navigation */
(function () {
    'use strict';

    function init() {
        var toggle = document.getElementById('nav-toggle');
        var container = document.getElementById('main-nav');

        if (!toggle || !container) return;

        toggle.addEventListener('click', function () {
            container.classList.toggle('mobile-menu-open');
            var expanded = container.classList.contains('mobile-menu-open');
            toggle.setAttribute('aria-expanded', expanded);
        });

        // Close menu when a nav link is tapped (single-page feel)
        container.addEventListener('click', function (e) {
            var link = e.target.closest('a');
            if (link && container.classList.contains('mobile-menu-open')) {
                // Allow the link to navigate but close the menu
                setTimeout(function () {
                    container.classList.remove('mobile-menu-open');
                    toggle.setAttribute('aria-expanded', 'false');
                }, 150);
            }
        });

        // Close menu on outside click
        document.addEventListener('click', function (e) {
            if (!container.contains(e.target)) {
                container.classList.remove('mobile-menu-open');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
